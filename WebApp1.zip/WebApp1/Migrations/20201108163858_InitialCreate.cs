﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApp1.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Employee",
                columns: table => new
                {
                    EmployeeID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeNum = table.Column<int>(nullable: false),
                    Department = table.Column<string>(nullable: true),
                    JobRole = table.Column<string>(nullable: true),
                    BusinessTravel = table.Column<string>(nullable: true),
                    EmployeeCount = table.Column<int>(nullable: false),
                    Attrition = table.Column<string>(nullable: true),
                    WorkLifeBalance = table.Column<string>(nullable: true),
                    PerformanceRating = table.Column<int>(nullable: false),
 
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.EmployeeID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Employee");
        }
    }
}
