﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using WebApp1.Data;


namespace WebApp1.Models
{
    public static class SeedData
    { 
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new EmployeeContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<EmployeeContext>>()))
            {
                // Look for any Employees.
                if (context.Employee.Any())
                {
                    return;   // DB has been seeded
                }

                context.Employee.AddRange(
                    new Employee
                    {
                        EmployeeNum = 1,
                        Department = "Science",
                        JobRole = "Manager",
                        BusinessTravel = "Yes",
                        EmployeeCount = 1729,
                        Attrition = "Value",
                        WorkLifeBalance = "5-7",
                        PerformanceRating = 7

                    },

                    new Employee
                    {
                        EmployeeNum = 2,
                        Department = "Education",
                        JobRole = "Manager",
                        BusinessTravel = "Yes",
                        EmployeeCount = 221,
                        Attrition = "Value",
                        WorkLifeBalance = "5-6",
                        PerformanceRating = 4

                    },

                    new Employee
                    {
                        EmployeeNum = 3,
                        Department = "Science",
                        JobRole = "Employee",
                        BusinessTravel = "No",
                        EmployeeCount = 5468,
                        Attrition = "Value",
                        WorkLifeBalance = "3-7",
                        PerformanceRating = 9

                    },

                    new Employee
                    {
                        EmployeeNum = 4,
                        Department = "Healthcare",
                        JobRole = "Manager",
                        BusinessTravel = "Yes",
                        EmployeeCount = 874,
                        Attrition = "Value",
                        WorkLifeBalance = "6-4",
                        PerformanceRating = 6

                    },

                    new Employee
                    {
                        EmployeeNum = 5,
                        Department = "Science",
                        JobRole = "Employee",
                        BusinessTravel = "Yes",
                        EmployeeCount = 1520,
                        Attrition = "Value",
                        WorkLifeBalance = "5-7",
                        PerformanceRating = 5

                    }
                );
                context.SaveChanges();
            }
        }
    }
}
