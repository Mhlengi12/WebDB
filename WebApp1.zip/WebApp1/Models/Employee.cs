﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApp1.Models
{
    public class Employee
    {
        
        public int EmployeeID { get; set; }
        [Required]
        public int EmployeeNum { get; set; }
        [StringLength(60, MinimumLength = 3)]
        [Required]
        public string Department { get; set; }
        [StringLength(60, MinimumLength = 3)]
        public string JobRole { get; set; }
        public string BusinessTravel { get; set; }
        public int EmployeeCount { get; set; }
        public string Attrition { get; set; }
        public string WorkLifeBalance { get; set; }
        public int PerformanceRating { get; set; }
    }
}
